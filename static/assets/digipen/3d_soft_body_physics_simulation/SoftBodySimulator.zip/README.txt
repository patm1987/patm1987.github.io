Patrick Martin
PHY350
Simulation

------------------------------------------------------------
Starting the Simulation
	Double click "run.bat" or type "run" from a dos prompt

------------------------------------------------------------
User Interface Overview

Left side:
	Along the left side of the main windows is a tree view of all the objects in the scene.  Below that are three buttons for adding new objects to the scene.  Any item under the "Soft Objects" branch may be double clicked on to open a "Soft Body Editor."  Other items may or may not cause a crash, it is suggested that you avoid double clicking on any other items in the list.

Menu:
	The Edit menu allows you to add a camera or remove the currently active camera.  If you do not add a camera through this menu, you will not be able to adjust the viewport and the far clipping plane may be closer than desired.

Soft Body Editor:
	Double clicking on any soft body object in the tree view will open the soft body editor.  This allows you to adjust the four main constants for the simulation: the spring constant (k), the molar count (n), the ideal gas constant (R - normally 8.314472), and the absolute temperature (T).  It should be noted that n, R, and T are multiplied together to form the pressure force so setting any one of these to zero will entirely disable any pressure simulation whereas disabling k will disable any spring simulation.  Both of these forces are necissary for correct soft body simulation.
	All values In this editor are locked between 0 and 500, and a maximum of six decimal places are allowed (although lowering any variable below 1 usually results in an unrealistic simulation.  Additionally, the numbers that are visible when the box opens up are not the actual values of those constants for those object.  The constants are only changed when the "Apply" button is hit.
	Recommended values for objects:
		R and T do not need adjustment

		Spheres (Add Soft Object button):
			k: 50
			n: 100
			It should be noted that the size of spheres will change drastically while adjusting these constants
		
		Torus (Add Torus button):
			k: 400
			n: 10 is good for maintaining the general shape and flexibility
			   100 is good for a "tire" and rolling around
			It should be noted that torus will tend to not grow or shrink as drastically as spheres.
			

------------------------------------------------------------
Controls
	Q - Pause/Unpause Simulation (camera may still be moved while paused)
	E - Progress one frame (1/60th of a second) when paused

	If you added a camera:
		left click + drag rotates the camera about the origin
		middle scroll wheel zooms the camera

	Moving Objects:
		First select the object from the object tree on the left, then click in the viewport

		If any object is selected (other than a camera or "Undefined Object"):
			W - move forward
			A - move back
			S - move left
			D - move right
			Space - move up

		If a rigid object is selected
			Numpad 8/2 rotate around the x axis
			Numpad 4/6 rotate around the y axis
			Numpad 7/9 rotate around the z axis

	All translational motion is with respect to the world frame (it will not adjust according to the camera position)
	All rotational motion is with respect to the object's local coordinate system (not the world coordinate system)
	I use the right handed coordinate system:
		+x - left
		+y - depth (into the screen)
		+z - up

------------------------------------------------------------
Known System Requirements:

Windows XP - Vista
Direct X
.NET Framework 2.0 - 3.0
A video card supporting pixel shader 3.0 (untested in pascal but those computers will probably not work)
Fast cpu (tested on Pentium D 3 GHz in Renoir, Core 2 Duo 1.6 GHz, and Athlon X2 4600+ 2.4 GHz)


------------------------------------------------------------
Known Project Building Requirements

Visual Studio 2005 with C++ and C# support
.NET Framework 2.0 or later
Direct X SDK

Ensure that the Direct X SDK is in Visual Studio's path, I do not specify the SDK directory in my project files to maintain compatibility between multiple versions of the SDK.


------------------------------------------------------------
Project Source Overview

	The solution is split into two main projects and a content section.

Phy350Simulation:
	Written in C#
	Provides the user interface and time control portions of the simulation
	Builds into an EXE
	Double clicking on any of the buttons in PhysicsForm.cs when in the visual editor will take you to the code that constructs the objects in the scene if you wish to change variables such as mass or radius.  The actual grunt work for these functions is performed in GeometryConstruction.cpp.

PhysicsEngine:
	Written in C++ (managed extensions used only in CLREntityParser, GeometryConstruction, AssemblyInfo, Native, and any file with the word Managed in it)
	Provides the graphics and physics simulation
	Compiled to a mixed-mode dll
	Each individual section is sorted according to a virtual folder heiarchy.
	Most of my storage classes are under Property->Properties

Content:
	Only contains the shader file
	Written in HLSL
	Compiled at runtime
	This is unimportant for the simulation and the shader may be disabled by uncommenting #define DISABLE_SHADERS in Stdafx.h.  This provides phong lighting for the project (otherwise it will be flat shaded and it will be fairly difficult to discern depth). It is only necessary to disable shaders if all objects appear solid black or you receive an error dialog on startup.  Any framerate drops lie in the actual physics simulation and not in any of the graphics operations.
	The shininess coefficient may also be changed here to increase or decrease the white spots on objects (line 55, output.Shiney = 150.f;).